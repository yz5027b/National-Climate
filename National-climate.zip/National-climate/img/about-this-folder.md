
Images go in this folder.

Put image citations in the main README.md file.